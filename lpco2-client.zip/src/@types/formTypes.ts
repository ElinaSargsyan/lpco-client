export interface ISelectControllerField {
  onChange: (selected?: OptionsItemType) => void;
  value: OptionsItemType;
}
