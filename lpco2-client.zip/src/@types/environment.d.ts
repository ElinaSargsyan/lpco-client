declare let process: {
  env: {
    NODE_ENV: string;
    VERSION: string;
    COMMITHASH: string;
    BRANCH: string;
    REACT_APP_PUBLIC_PATH: string;
    REACT_APP_API_URL: string;
  };
};
