import { PUBLIC_PATH } from '../config';

export const appPaths = {
  indexPath: PUBLIC_PATH,
};
