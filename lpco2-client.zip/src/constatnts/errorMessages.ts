export const mandatoryField = 'This field is mandatory';
export const validPhoneNumberField = 'Phone number is not valid';
export const zeroOrPositive = 'This field should be only 0 or positive';
export const currentDate = 'Can not be greater than current date';
export const grossMassError = 'Can not be greater than gross mass';
export const validEmail = 'Please enter a valid email address';
