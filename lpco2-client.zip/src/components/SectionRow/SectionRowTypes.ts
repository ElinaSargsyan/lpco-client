export interface ISectionRowProps extends IWithReactChildren {
  className?: string;
}
