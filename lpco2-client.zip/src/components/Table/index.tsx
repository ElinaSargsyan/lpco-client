import { Table as WFTable } from '@wf/components';

import Table from './Table';

export default Object.assign(Table, {
  ...WFTable,
});
