export interface IRightItemWithTwoField extends IWithReactChildren {
  className?: string;
}
