export interface ILabelProps extends IWithReactChildren {
  icon?: string;
  mandatory?: boolean;
}
