export interface IRightItemWithOneField extends IWithReactChildren {
  className?: string;
}
