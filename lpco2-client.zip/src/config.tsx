export const APP_SERVER = process.env.REACT_APP_API_URL;
export const PUBLIC_PATH = process.env.REACT_APP_PUBLIC_PATH;
export const LPCO_SERVER = `${APP_SERVER}/lpco2`;
export const LPCO_ADMIN_SERVER = `${APP_SERVER}/lpco2-admin`;
export const RIMM_SERVER = `${APP_SERVER}/rimm`;
