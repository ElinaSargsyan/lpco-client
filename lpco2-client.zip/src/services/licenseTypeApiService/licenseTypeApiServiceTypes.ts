export interface ILicenseTypeByCodeParams {
  withId?: boolean;
  licenseTypeCode: string;
}
