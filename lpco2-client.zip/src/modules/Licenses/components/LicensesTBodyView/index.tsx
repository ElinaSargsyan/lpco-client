export { default } from './LicensesTBodyView';
