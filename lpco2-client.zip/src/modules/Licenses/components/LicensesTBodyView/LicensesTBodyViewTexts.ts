import { APPNAME } from '../../../../constatnts';

const STATUS = 'Status';
const TYPE_OF_LPCO = `Type of ${APPNAME}`;
const USER_REF_NUMBER = 'User Ref. Number';
const APPROVAL_REF = 'Approval Ref.';
const APPROVAL_DATE = 'Approval Date';
const COMPANY_CODE = 'Company Code';

export default {
  STATUS,
  TYPE_OF_LPCO,
  USER_REF_NUMBER,
  APPROVAL_REF,
  APPROVAL_DATE,
  COMPANY_CODE,
};
