import { APPNAME } from '../../../../constatnts';

const TITTLE = APPNAME;
const NEW_REQUESTS = 'New Requests';
const LPCO_LIST = `${APPNAME} List`;
const NEW_REQ_EMPTY_DATA_TITTLE = 'No new requests data yet';
const NEW_REQ_EMPTY_DATA_DESC = 'This is place holder text. The basic dialog for tables';
const LPCO_LIST_EMPTY_DATA_TITTLE = `No ${APPNAME} list data yet`;
const LPCO_LIST_EMPTY_DATA_DESC = 'This is place holder text. The basic dialog for tables';

export default {
  TITTLE,
  NEW_REQUESTS,
  LPCO_LIST,
  NEW_REQ_EMPTY_DATA_TITTLE,
  NEW_REQ_EMPTY_DATA_DESC,
  LPCO_LIST_EMPTY_DATA_TITTLE,
  LPCO_LIST_EMPTY_DATA_DESC,
};
