export { default } from './LicensesView';
