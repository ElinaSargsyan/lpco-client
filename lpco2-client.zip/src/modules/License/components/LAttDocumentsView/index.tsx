export { default } from './LAttDocumentsView';
