export { default } from './LAttDocumentPopupContentView';
