export { default } from './LAttDocumentsBodyView';
