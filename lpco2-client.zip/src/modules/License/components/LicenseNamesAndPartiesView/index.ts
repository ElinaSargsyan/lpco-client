export { default } from './LicenseNamesAndPartiesView';
