export { default } from './LicenseHeaderView';
