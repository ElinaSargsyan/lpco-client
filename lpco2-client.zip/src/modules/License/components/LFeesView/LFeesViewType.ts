export interface ILFeesViewTHeaderItem {
  name: string;
  flex: number;
}
