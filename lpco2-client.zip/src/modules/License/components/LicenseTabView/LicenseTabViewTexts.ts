const HEADER = 'Header';
const NAMES_AND_PARTIES = 'Names & Parties';
const ITEMS = 'Items';
const ATTACHED_DOCUMENTS = 'Attached Documents';
const BENEFICIARIES = 'Beneficiaries';
const FEES = 'Fees';

export default {
  HEADER,
  NAMES_AND_PARTIES,
  ITEMS,
  ATTACHED_DOCUMENTS,
  BENEFICIARIES,
  FEES,
};
