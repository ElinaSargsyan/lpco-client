export { default } from './LicenseTabView';
