export { default } from './LBeneficiariesView';
