export { default } from './LBeneficiariesBodyView';
