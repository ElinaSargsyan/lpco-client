export { default } from './LBeneficiaryPopupContentView';
