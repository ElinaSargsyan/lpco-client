export { default } from './LicenseNamesAndPartiesContainer';
