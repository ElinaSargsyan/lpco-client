export { default } from './License';
