const LICENE_VIEW_TITLE_TEXT = 'View Application';
const LICENE_CREATE_TITLE_TEXT = 'Fill New Application';
const LICENE_EDIT_TITLE_TEXT = 'Edit Application';

export default {
  LICENE_VIEW_TITLE_TEXT,
  LICENE_CREATE_TITLE_TEXT,
  LICENE_EDIT_TITLE_TEXT,
};
