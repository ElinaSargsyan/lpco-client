export { default } from './LBeneficiariesContainer';
