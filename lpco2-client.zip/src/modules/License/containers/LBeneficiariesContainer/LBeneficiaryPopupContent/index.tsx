export { default } from './LBeneficiaryPopupContent';
