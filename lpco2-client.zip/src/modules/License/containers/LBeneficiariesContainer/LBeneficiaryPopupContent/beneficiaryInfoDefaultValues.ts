export const beneficiaryInfoDefaultValues = {
  code: null,
  description: '',
  phoneNumber: '',
  email: '',
};
