export interface IBeneficiaryFormData {
  code: OptionsItemType;
  description: string;
  phoneNumber: string;
  email: string;
}
