export { default } from './LItemPopupContent';
