export { default } from './LicenseHeaderContainer';
