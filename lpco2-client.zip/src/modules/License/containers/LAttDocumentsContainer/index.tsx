export { default } from './LAttDocumentsContainer';
