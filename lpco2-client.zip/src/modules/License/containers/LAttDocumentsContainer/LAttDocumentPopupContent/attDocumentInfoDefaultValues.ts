export const attDocumentInfoDefaultValues = {
  code: null,
  referenceNumber: '',
  attachmentDate: null,
  fileUrl: '',
};
