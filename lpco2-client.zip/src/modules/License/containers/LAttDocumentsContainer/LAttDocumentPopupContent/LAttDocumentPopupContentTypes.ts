export interface IAttDocumentFormData {
  code: OptionsItemType;
  name: string;
  referenceNumber: string;
  attachmentDate: string | null;
  fileUrl: string;
}
