const TITTLE = 'Document History';
const DOCUMENT_HISTORY_EMPTY_DATA_TITLE = 'No new requests data yet';
const DOCUMENT_HISTORY_EMPTY_DATA_DESC = 'This is place holder text. The basic dialog for tables';

export default {
  TITTLE,
  DOCUMENT_HISTORY_EMPTY_DATA_TITLE,
  DOCUMENT_HISTORY_EMPTY_DATA_DESC,
};
