const OPERATION_DATE = 'Operation Date';
const USER = 'User';
const COMMITED_OPERATIONS = 'Commited Operations';
const NEW_STATUSES = 'New Status';

export default {
  OPERATION_DATE,
  USER,
  COMMITED_OPERATIONS,
  NEW_STATUSES,
};
