import type { DocumentHistoryState } from './types';

export const initialState: DocumentHistoryState = {
  documentHistoryData: [],
};
