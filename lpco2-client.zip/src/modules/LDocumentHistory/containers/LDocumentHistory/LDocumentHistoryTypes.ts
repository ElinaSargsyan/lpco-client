export interface ILDocumentHistoryProps {
  id: string;
  emptyDataTitle: string;
  emptyDataText: string;
}
