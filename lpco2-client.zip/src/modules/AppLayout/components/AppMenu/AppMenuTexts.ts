import { APPNAME } from '../../../../constatnts';

const LPCO = APPNAME;

export default {
  LPCO,
};
