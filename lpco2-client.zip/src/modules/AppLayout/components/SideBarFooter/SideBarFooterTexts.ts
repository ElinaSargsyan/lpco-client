const LOG_OUT = 'Log out';
const ALL_APPS = 'All apps';

export default {
  LOG_OUT,
  ALL_APPS,
};
