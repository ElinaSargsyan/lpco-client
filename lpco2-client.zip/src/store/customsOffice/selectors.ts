import type { RootState } from '../index';

export const customsOfficeDataSelector = (state: RootState) => state.customsOffice.data;
