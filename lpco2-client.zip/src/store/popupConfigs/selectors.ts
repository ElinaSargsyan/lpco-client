import type { RootState } from '../index';

export const popupConfigsDataSelector = (state: RootState) => state.popupConfigs.data;
