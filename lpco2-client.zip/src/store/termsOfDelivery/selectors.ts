import type { RootState } from '../index';

export const termsOfDeliveryDataSelector = (state: RootState) => state.termsOfDelivery.data;
