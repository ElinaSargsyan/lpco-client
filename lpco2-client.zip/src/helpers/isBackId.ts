export function isBackId(id: number) {
  return id < 10000;
}
