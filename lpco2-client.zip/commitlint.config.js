module.exports = require('@wf/configs/commitlint.config');
